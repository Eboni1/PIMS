<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../index.php');
    exit();
}

// Check if user has correct role
if ($_SESSION['role'] !== 'system_admin') {
    header('Location: ../index.php');
    exit();
}

require_once '../config.php';

// Include helper functions first
if (!function_exists('logSystemAction')) {
    function logSystemAction($user_id, $action, $module, $details = null) {
        global $conn;
        
        try {
            $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
            $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
            
            $stmt = $conn->prepare("
                INSERT INTO system_logs (user_id, action, module, details, ip_address, user_agent) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("isssss", $user_id, $action, $module, $details, $ip_address, $user_agent);
            $stmt->execute();
            $stmt->close();
            
            return true;
        } catch (Exception $e) {
            error_log("Failed to log system action: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('backupDatabasePHP')) {
    function backupDatabasePHP($filename, $conn, $database) {
        try {
            $tables = array();
            $result = $conn->query("SHOW TABLES");
            while ($row = $result->fetch_row()) {
                $tables[] = $row[0];
            }
            
            $sql = "";
            foreach ($tables as $table) {
                $sql .= "DROP TABLE IF EXISTS `$table`;\n";
                
                $createTable = $conn->query("SHOW CREATE TABLE `$table`");
                $row = $createTable->fetch_row();
                $sql .= $row[1] . ";\n\n";
                
                $result = $conn->query("SELECT * FROM `$table`");
                $numColumns = $result->field_count;
                
                while ($row = $result->fetch_row()) {
                    $sql .= "INSERT INTO `$table` VALUES(";
                    for ($i = 0; $i < $numColumns; $i++) {
                        $row[$i] = addslashes($row[$i]);
                        $row[$i] = str_replace("\n", "\\n", $row[$i]);
                        if (isset($row[$i])) {
                            $sql .= '"' . $row[$i] . '"';
                        } else {
                            $sql .= '""';
                        }
                        if ($i < $numColumns - 1) {
                            $sql .= ',';
                        }
                    }
                    $sql .= ");\n";
                }
                $sql .= "\n\n";
            }
            
            return file_put_contents($filename, $sql) !== false;
            
        } catch (Exception $e) {
            error_log("PHP database backup error: " . $e->getMessage());
            return false;
        }
    }
}

// Handle online backup creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_online_backup'])) {
    $backup_name = trim($_POST['backup_name']);
    $backup_type = $_POST['backup_type'];
    $storage_type = $_POST['storage_type'];
    $include_files = isset($_POST['include_files']);
    $include_database = isset($_POST['include_database']);
    
    $errors = [];
    
    if (empty($backup_name)) {
        $errors[] = 'Backup name is required';
    }
    
    if (empty($errors)) {
        try {
            // Create backup directory if it doesn't exist
            $backup_dir = '../temp_backups';
            if (!is_dir($backup_dir)) {
                mkdir($backup_dir, 0755, true);
            }
            
            $timestamp = date('Y-m-d_H-i-s');
            $backup_filename = $backup_name . '_' . $timestamp;
            $backup_path = $backup_dir . '/' . $backup_filename;
            
            // Create local backup first
            $backup_files = [];
            
            if ($include_database) {
                $db_backup_file = $backup_path . '_database.sql';
                $backup_success = backupDatabasePHP($db_backup_file, $conn, $database);
                if ($backup_success) {
                    $backup_files[] = $db_backup_file;
                } else {
                    $errors[] = 'Database backup failed';
                }
            }
            
            if ($include_files && empty($errors)) {
                if (class_exists('ZipArchive')) {
                    $zip_file = $backup_path . '_files.zip';
                    $zip = new ZipArchive();
                    
                    if ($zip->open($zip_file, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
                        $directories_to_backup = ['ADMIN', 'OFFICE_ADMIN', 'SYSTEM_ADMIN', 'USER', 'assets'];
                        
                        foreach ($directories_to_backup as $dir) {
                            if (is_dir('../' . $dir)) {
                                $files = new RecursiveIteratorIterator(
                                    new RecursiveDirectoryIterator('../' . $dir),
                                    RecursiveIteratorIterator::LEAVES_ONLY
                                );
                                
                                foreach ($files as $name => $file) {
                                    if (!$file->isDir()) {
                                        $filePath = $file->getRealPath();
                                        $relativePath = substr($filePath, strlen(realpath('../')) + 1);
                                        $zip->addFile($filePath, $relativePath);
                                    }
                                }
                            }
                        }
                        
                        $important_files = ['config.php', 'index.php', 'change_password.php', 'forgot_password.php', 'logout.php', 'reset_password.php'];
                        foreach ($important_files as $file) {
                            if (file_exists('../' . $file)) {
                                $zip->addFile('../' . $file, $file);
                            }
                        }
                        
                        $zip->close();
                        $backup_files[] = $zip_file;
                    } else {
                        $errors[] = 'Failed to create files backup archive';
                    }
                } else {
                    $errors[] = 'ZipArchive extension not available';
                }
            }
            
            // Upload to online storage
            if (empty($errors) && !empty($backup_files)) {
                $upload_result = uploadToOnlineStorage($backup_files, $storage_type, $backup_name, $timestamp);
                
                if ($upload_result['success']) {
                    // Save backup record to database
                    $stmt = $conn->prepare("
                        INSERT INTO online_backups (name, type, storage_type, include_files, include_database, file_url, file_size, created_by, created_at) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
                    ");
                    $stmt->bind_param("sssiisii", $backup_name, $backup_type, $storage_type, $include_files, $include_database, 
                                       $upload_result['url'], $upload_result['size'], $_SESSION['user_id']);
                    $stmt->execute();
                    $stmt->close();
                    
                    logSystemAction($_SESSION['user_id'], 'online_backup_created', 'online_backup', 
                                   "Backup: $backup_name, Storage: $storage_type");
                    
                    $success_message = 'Online backup created successfully!';
                    
                    // Clean up temporary files
                    foreach ($backup_files as $file) {
                        if (file_exists($file)) {
                            unlink($file);
                        }
                    }
                } else {
                    $errors[] = 'Upload failed: ' . $upload_result['error'];
                }
            }
            
        } catch (Exception $e) {
            error_log("Online backup creation error: " . $e->getMessage());
            $errors[] = 'Backup creation failed: ' . $e->getMessage();
        }
    }
}

// Get existing online backups
$online_backups = [];
try {
    $stmt = $conn->prepare("
        SELECT ob.*, u.first_name, u.last_name, u.username 
        FROM online_backups ob 
        LEFT JOIN users u ON ob.created_by = u.id 
        ORDER BY ob.created_at DESC
    ");
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $online_backups[] = $row;
    }
    $stmt->close();
} catch (Exception $e) {
    error_log("Error fetching online backups: " . $e->getMessage());
}

// Function to upload to online storage
function uploadToOnlineStorage($files, $storage_type, $backup_name, $timestamp) {
    try {
        switch ($storage_type) {
            case 'local':
                return uploadToLocal($files, $backup_name, $timestamp);
            case 'ftp':
                return uploadToFTP($files, $backup_name, $timestamp);
            case 'google_drive':
                return uploadToGoogleDrive($files, $backup_name, $timestamp);
            case 'dropbox':
                return uploadToDropbox($files, $backup_name, $timestamp);
            default:
                return ['success' => false, 'error' => 'Unknown storage type'];
        }
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

function uploadToLocal($files, $backup_name, $timestamp) {
    $target_dir = '../online_backups';
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0755, true);
    }
    
    $total_size = 0;
    $uploaded_files = [];
    
    foreach ($files as $file) {
        $filename = basename($file);
        $target_file = $target_dir . '/' . $backup_name . '_' . $timestamp . '_' . $filename;
        
        if (copy($file, $target_file)) {
            $total_size += filesize($target_file);
            $uploaded_files[] = $target_file;
        } else {
            // Cleanup on failure
            foreach ($uploaded_files as $uploaded) {
                if (file_exists($uploaded)) {
                    unlink($uploaded);
                }
            }
            return ['success' => false, 'error' => 'Failed to copy file: ' . $filename];
        }
    }
    
    return [
        'success' => true, 
        'url' => $target_dir . '/' . $backup_name . '_' . $timestamp,
        'size' => $total_size
    ];
}

function uploadToFTP($files, $backup_name, $timestamp) {
    // FTP configuration - these should be stored securely
    $ftp_host = 'ftp.example.com';
    $ftp_user = 'username';
    $ftp_pass = 'password';
    $ftp_dir = '/backups/';
    
    $conn_id = ftp_connect($ftp_host);
    if (!$conn_id) {
        return ['success' => false, 'error' => 'FTP connection failed'];
    }
    
    $login_result = ftp_login($conn_id, $ftp_user, $ftp_pass);
    if (!$login_result) {
        ftp_close($conn_id);
        return ['success' => false, 'error' => 'FTP login failed'];
    }
    
    $total_size = 0;
    foreach ($files as $file) {
        $filename = basename($file);
        $remote_file = $ftp_dir . $backup_name . '_' . $timestamp . '_' . $filename;
        
        if (ftp_put($conn_id, $remote_file, $file, FTP_BINARY)) {
            $total_size += filesize($file);
        } else {
            ftp_close($conn_id);
            return ['success' => false, 'error' => 'FTP upload failed for: ' . $filename];
        }
    }
    
    ftp_close($conn_id);
    return [
        'success' => true, 
        'url' => 'ftp://' . $ftp_host . $ftp_dir . $backup_name . '_' . $timestamp,
        'size' => $total_size
    ];
}

function uploadToGoogleDrive($files, $backup_name, $timestamp) {
    // This would require Google Drive API integration
    // For now, return a placeholder response
    return [
        'success' => false, 
        'error' => 'Google Drive integration not yet implemented'
    ];
}

function uploadToDropbox($files, $backup_name, $timestamp) {
    // This would require Dropbox API integration
    // For now, return a placeholder response
    return [
        'success' => false, 
        'error' => 'Dropbox integration not yet implemented'
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Backup - PIMS</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../assets/css/index.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #F7F3F3 0%, #C1EAF2 100%);
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        .page-header {
            background: white;
            border-radius: var(--border-radius-xl);
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow);
            border-left: 4px solid var(--primary-color);
        }
        
        .backup-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
            border-left: 4px solid #191BA9;
        }
        
        .storage-option {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            border-left: 4px solid #191BA9;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .storage-option:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }
        
        .storage-option.selected {
            border-left-color: #28a745;
            background: linear-gradient(135deg, rgba(40, 167, 69, 0.1) 0%, rgba(25, 27, 169, 0.1) 100%);
        }
        
        .form-control, .form-select {
            border-radius: 10px;
            border: 2px solid #e9ecef;
            padding: 0.75rem 1rem;
            transition: all 0.3s ease;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #191BA9;
            box-shadow: 0 0 0 0.2rem rgba(25, 27, 169, 0.25);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #191BA9 0%, #5CC2F2 100%);
            border: none;
            border-radius: 10px;
            padding: 0.75rem 2rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(25, 27, 169, 0.3);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            border: none;
            border-radius: 10px;
            padding: 0.75rem 2rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-info {
            background: linear-gradient(135deg, #17a2b8 0%, #6c757d 100%);
            border: none;
            border-radius: 10px;
            padding: 0.75rem 2rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .storage-icon {
            font-size: 2rem;
            color: #191BA9;
            margin-bottom: 1rem;
        }
        
        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        
        .stats-card:hover {
            transform: translateY(-5px);
        }
        
        .stats-number {
            font-size: 2rem;
            font-weight: 700;
            color: #191BA9;
        }
    </style>
</head>
<body>
    <?php
    $page_title = 'Online Backup';
    ?>
    <div class="main-wrapper" id="mainWrapper">
        <?php require_once 'includes/sidebar-toggle.php'; ?>
        <?php require_once 'includes/sidebar.php'; ?>
        <?php require_once 'includes/topbar.php'; ?>
    
        <div class="main-content">
            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h1 class="mb-2">
                            <i class="bi bi-cloud-upload"></i> Online Backup
                        </h1>
                        <p class="text-muted mb-0">Store backups in cloud storage or remote locations</p>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createOnlineBackupModal">
                            <i class="bi bi-plus-circle"></i> Create Online Backup
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Success/Error Messages -->
            <?php if (isset($success_message)): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle"></i>
                    <?php echo htmlspecialchars($success_message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if (isset($error_message)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle"></i>
                    <?php echo htmlspecialchars($error_message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle"></i>
                    <strong>Error:</strong>
                    <ul class="mb-0 mt-2">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- Statistics -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-number"><?php echo count($online_backups); ?></div>
                        <div class="text-muted">Online Backups</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-number">
                            <?php 
                            $total_size = array_sum(array_column($online_backups, 'file_size'));
                            echo round($total_size / 1024 / 1024, 2) . ' MB';
                            ?>
                        </div>
                        <div class="text-muted">Total Storage</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-number">
                            <?php 
                            $recent_backups = array_filter($online_backups, function($backup) {
                                return strtotime($backup['created_at']) > strtotime('-7 days');
                            });
                            echo count($recent_backups);
                            ?>
                        </div>
                        <div class="text-muted">Last 7 Days</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-number">
                            <?php 
                            $latest_backup = !empty($online_backups) ? $online_backups[0]['created_at'] : 'Never';
                            echo !empty($online_backups) ? date('M j', strtotime($latest_backup)) : 'Never';
                            ?>
                        </div>
                        <div class="text-muted">Last Backup</div>
                    </div>
                </div>
            </div>
            
            <!-- Storage Options -->
            <div class="backup-card">
                <h4 class="mb-4"><i class="bi bi-cloud"></i> Available Storage Options</h4>
                <div class="row">
                    <div class="col-md-6">
                        <div class="storage-option" onclick="selectStorage('local')">
                            <div class="storage-icon">
                                <i class="bi bi-hdd"></i>
                            </div>
                            <h5>Local Storage</h5>
                            <p class="text-muted">Store backups on local server storage</p>
                            <small class="text-success">✓ Available</small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="storage-option" onclick="selectStorage('ftp')">
                            <div class="storage-icon">
                                <i class="bi bi-network"></i>
                            </div>
                            <h5>FTP/SFTP</h5>
                            <p class="text-muted">Upload to remote FTP server</p>
                            <small class="text-success">✓ Available</small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="storage-option" onclick="selectStorage('google_drive')">
                            <div class="storage-icon">
                                <i class="bi bi-google"></i>
                            </div>
                            <h5>Google Drive</h5>
                            <p class="text-muted">Store backups in Google Drive</p>
                            <small class="text-warning">⚠ Coming Soon</small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="storage-option" onclick="selectStorage('dropbox')">
                            <div class="storage-icon">
                                <i class="bi bi-dropbox"></i>
                            </div>
                            <h5>Dropbox</h5>
                            <p class="text-muted">Store backups in Dropbox</p>
                            <small class="text-warning">⚠ Coming Soon</small>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Online Backup History -->
            <div class="backup-card">
                <h4 class="mb-4"><i class="bi bi-clock-history"></i> Online Backup History</h4>
                
                <?php if (empty($online_backups)): ?>
                    <div class="text-center py-5">
                        <i class="bi bi-cloud-upload fs-1 text-muted"></i>
                        <p class="text-muted mt-3">No online backups found. Create your first online backup to get started.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($online_backups as $backup): ?>
                        <div class="storage-option">
                            <div class="row align-items-center">
                                <div class="col-md-6">
                                    <h5 class="mb-1"><?php echo htmlspecialchars($backup['name']); ?></h5>
                                    <p class="text-muted mb-2">
                                        <small>
                                            <i class="bi bi-person"></i> <?php echo htmlspecialchars($backup['first_name'] . ' ' . $backup['last_name']); ?> •
                                            <i class="bi bi-calendar"></i> <?php echo date('M j, Y H:i:s', strtotime($backup['created_at'])); ?>
                                        </small>
                                    </p>
                                    <div>
                                        <span class="badge bg-info">
                                            <i class="bi bi-cloud"></i> <?php echo htmlspecialchars($backup['storage_type']); ?>
                                        </span>
                                        <?php if ($backup['include_database']): ?>
                                            <span class="badge bg-success ms-2">
                                                <i class="bi bi-database"></i> Database
                                            </span>
                                        <?php endif; ?>
                                        <?php if ($backup['include_files']): ?>
                                            <span class="badge bg-secondary ms-2">
                                                <i class="bi bi-folder"></i> Files
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <p class="mb-1">
                                        <strong>Size:</strong> 
                                        <?php echo round($backup['file_size'] / 1024 / 1024, 2) . ' MB'; ?>
                                    </p>
                                </div>
                                <div class="col-md-3 text-md-end">
                                    <button class="btn btn-sm btn-info me-2" onclick="downloadBackup('<?php echo htmlspecialchars($backup['file_url']); ?>')">
                                        <i class="bi bi-download"></i> Download
                                    </button>
                                    <button class="btn btn-sm btn-danger" 
                                            onclick="confirmDeleteOnlineBackup(<?php echo $backup['id']; ?>, '<?php echo htmlspecialchars($backup['name']); ?>')">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Create Online Backup Modal -->
    <div class="modal fade" id="createOnlineBackupModal" tabindex="-1" aria-labelledby="createOnlineBackupModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="online_backup.php">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title" id="createOnlineBackupModalLabel">
                            <i class="bi bi-cloud-upload"></i> Create Online Backup
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="backup_name" class="form-label">Backup Name</label>
                            <input type="text" class="form-control" id="backup_name" name="backup_name" 
                                   placeholder="e.g., Daily Online Backup" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="backup_type" class="form-label">Backup Type</label>
                            <select class="form-select" id="backup_type" name="backup_type" required>
                                <option value="full">Full Backup</option>
                                <option value="database">Database Only</option>
                                <option value="files">Files Only</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="storage_type" class="form-label">Storage Location</label>
                            <select class="form-select" id="storage_type" name="storage_type" required>
                                <option value="local">Local Storage</option>
                                <option value="ftp">FTP/SFTP Server</option>
                                <option value="google_drive" disabled>Google Drive (Coming Soon)</option>
                                <option value="dropbox" disabled>Dropbox (Coming Soon)</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Include in Backup</label>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="include_database" name="include_database" checked>
                                <label class="form-check-label" for="include_database">
                                    <i class="bi bi-database"></i> Database Backup
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="include_files" name="include_files" checked>
                                <label class="form-check-label" for="include_files">
                                    <i class="bi bi-folder"></i> System Files
                                </label>
                            </div>
                        </div>
                        
                        <div class="alert alert-info" role="alert">
                            <i class="bi bi-info-circle"></i>
                            <strong>Note:</strong> Online backups are stored in your chosen cloud storage and can be accessed from anywhere.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="create_online_backup" class="btn btn-primary">
                            <i class="bi bi-cloud-upload"></i> Create Online Backup
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <?php require_once 'includes/logout-modal.php'; ?>
    <?php require_once 'includes/change-password-modal.php'; ?>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    
    <script>
        // Sidebar functionality
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');
        const mainWrapper = document.getElementById('mainWrapper');
        const navbar = document.querySelector('.navbar');

        if (sidebarToggle && sidebar && sidebarOverlay) {
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('active');
                sidebarOverlay.classList.toggle('active');
                mainWrapper.classList.toggle('sidebar-active');
                if (navbar) navbar.classList.toggle('sidebar-active');
                sidebarToggle.classList.toggle('sidebar-active');
            });

            sidebarOverlay.addEventListener('click', function() {
                sidebar.classList.remove('active');
                sidebarOverlay.classList.remove('active');
                mainWrapper.classList.remove('sidebar-active');
                if (navbar) navbar.classList.remove('sidebar-active');
                sidebarToggle.classList.remove('sidebar-active');
            });
        }
        
        // Storage selection
        function selectStorage(type) {
            document.getElementById('storage_type').value = type;
            
            // Update UI
            document.querySelectorAll('.storage-option').forEach(option => {
                option.classList.remove('selected');
            });
            event.currentTarget.classList.add('selected');
        }
        
        // Download backup
        function downloadBackup(url) {
            window.open(url, '_blank');
        }
        
        // Update backup type checkboxes
        document.getElementById('backup_type')?.addEventListener('change', function() {
            const includeDatabase = document.getElementById('include_database');
            const includeFiles = document.getElementById('include_files');
            
            if (this.value === 'database') {
                includeDatabase.checked = true;
                includeFiles.checked = false;
                includeFiles.disabled = true;
            } else if (this.value === 'files') {
                includeDatabase.checked = false;
                includeFiles.checked = true;
                includeDatabase.disabled = true;
            } else {
                includeDatabase.checked = true;
                includeFiles.checked = true;
                includeDatabase.disabled = false;
                includeFiles.disabled = false;
            }
        });
    </script>
</body>
</html>
